import random

def choose_random_word():
    words = ["mormon", "nephi", "moroni", "jacob", "enos", "abinadi", "ammon", "amulek", "alma", "benjamin"]
    return random.choice(words)

def display_word(word, guessed_letters):
    display = ""
    for char in word:
        if char.isalpha() and char in guessed_letters:
            display += char
        elif char.isalpha():
            display += "_"
        else:
            display += char
    return display

def intro():
    print("Let's remember the names of the prophets from the Book of Mormon!")
    print("")
    print("Instructions: All you have to do is to guess the prophet's name by entering any letter. We will let you know if the letter is part of the name or not.")
    print("")

    ready = input("Are you ready? (type: yes): ").lower()
    if ready == "yes":
        print("\nLet's start!")
    else:
        print('Type "yes" to start')

def hangman():
    word_to_guess = choose_random_word()
    guessed_letters = set()
    incorrect_attempts = 0
    correct_attempts = 0
    total_attempts = 0

    while "_" in display_word(word_to_guess, guessed_letters):
        print("\n" + display_word(word_to_guess, guessed_letters))
        guess = input("\nGuess a letter: ").lower()

        if guess.isalpha() and len(guess) == 1:
            total_attempts += 1
            if guess in guessed_letters:
                print("You already guessed that letter. Try again.")
            elif guess in word_to_guess:
                guessed_letters.add(guess)
                correct_attempts += 1
                print(f"\nGood guess!\nCorrect attempts: {correct_attempts}\nIncorrect attempts: {incorrect_attempts}\nTotal attempts: {total_attempts}")

            else:
                guessed_letters.add(guess)
                incorrect_attempts += 1
                print(f"\nWrong guess! Try again with a different letter\nCorrect attempts: {correct_attempts}\nIncorrect attempts: {incorrect_attempts}\nTotal attempts: {total_attempts}")
        else:
            print("Please enter a valid single letter.")

    print("\nCongratulations! You guessed the word:", display_word(word_to_guess, guessed_letters))
    print(f"\nTotal attempts: {total_attempts}\nCorrect attempts: {correct_attempts}\nIncorrect attempts: {incorrect_attempts}")

def play_again():
    play = input("\nDo you want to play again? (yes/no): ").lower()
    if play == "yes":
        return True
    if not ():
        print("Thank you for playing!")

# Run the game
intro()
hangman()
while play_again():
  hangman()  

